# CompanyFlow — Advanced Java Mini Project

## Title
**CompanyFlow: Local Company Registration & Task Management System**

## Proper Definition
CompanyFlow is a local, database-driven company management web application developed using **Java Servlets, JSP, Filters, JDBC and MySQL**. It provides a realistic registration and employee-workflow demonstration: employees can register and log in, an administrator can manage users and assign work, and employees can update the completion status of their assigned tasks.

The system is intentionally local and academic. It runs on **Apache Tomcat** and stores data in a local **MySQL** database. It does not require any live server, cloud database, payment system, or external API.

> **Important terminology:** ASP (Active Server Pages) is a Microsoft web technology, not the Java/Tomcat technology used here. For an Advanced Java project on Tomcat, the equivalent server-side page technology is **JSP (JavaServer Pages)**. This project therefore uses JSP + Servlets + Filters + JDBC.

## Functionality Included

### Public
- Home / project landing page
- Employee registration page
- Server-side validation
- Duplicate-email validation through database constraint

### Authentication
- Real database-backed login
- Session-based authentication
- Logout / session invalidation
- Role-based access: ADMIN and EMPLOYEE
- Authentication Filter for protected pages
- Admin Filter for admin-only pages

### Admin
- Dashboard with employee, administrator and task counts
- User insert/create
- User update
- User delete
- User search by name, email or department
- Task creation
- Task assignment to an employee
- Task update
- Task deletion
- Task search by title, status or employee
- Task status management
- Completed vs remaining work overview

### Employee
- Employee dashboard
- View assigned tasks
- Search-friendly task data model
- Checkbox to mark work completed
- Checkbox can move a completed task back to IN_PROGRESS
- Completed / remaining task count
- Completion percentage

### Technical Requirements Demonstrated
- JSP
- Servlets
- Filters
- HTTP sessions
- JDBC
- MySQL
- PreparedStatement
- Form validation
- Password hashing using PBKDF2-HMAC-SHA256
- MVC-style separation using model / DAO / servlet layers
- Local Apache Tomcat deployment

## Project Structure

```text
CompanyFlow/
├── pom.xml
├── database/
│   └── companyflow.sql
├── docs/
│   ├── PROJECT_DEFINITION.md
│   └── DEMO_SCRIPT.md
└── src/main/
    ├── java/com/companyflow/
    │   ├── dao/
    │   ├── filter/
    │   ├── model/
    │   ├── servlet/
    │   └── util/
    └── webapp/
        ├── assets/
        ├── WEB-INF/
        │   ├── views/admin/
        │   ├── views/employee/
        │   └── web.xml
        ├── index.jsp
        ├── login.jsp
        ├── register.jsp
        └── error.jsp
```

## Local Setup in Apache NetBeans

1. Start **MySQL** from XAMPP.
2. Open phpMyAdmin and import:
   `database/companyflow.sql`
3. Open **Apache NetBeans** → File → Open Project → select the `CompanyFlow` folder.
4. Configure a local **Apache Tomcat 10.1.x** server in NetBeans.
5. Run the Maven web project on Tomcat.
6. Open:
   `http://localhost:8080/CompanyFlow/`

Tomcat 10.1 implements Servlet 6.0 and JSP 3.1, which matches the Jakarta packages used by this project.

## Demo Admin Account

```text
Email:    admin@companyflow.local
Password: Admin@123
```

For a presentation, register one or two employee accounts and then use the admin account to assign tasks to them.

## Suggested Classroom Demo

1. Open the CompanyFlow home page.
2. Register an employee account.
3. Log in as the employee and show the empty work dashboard.
4. Log out.
5. Log in as admin.
6. Open Users and show create / edit / delete / search.
7. Open Tasks and create a task for the employee.
8. Assign a due date and show the task in the admin table.
9. Log out and log in as the employee.
10. Open My Work and check the task checkbox.
11. Show the status becoming COMPLETED and the completed / remaining counters changing.
12. Log in as admin again and show the same task as COMPLETED.

## Database Configuration

Default local configuration:

```text
Host: localhost
Port: 3306
Database: companyflow
User: root
Password: (blank)
```

To override user/password without editing source code, set:

```bash
export COMPANYFLOW_DB_USER=root
export COMPANYFLOW_DB_PASSWORD=your_password
```

## Security Notes

Passwords are not stored as plain text. The project hashes them using PBKDF2-HMAC-SHA256 with a per-password random salt. For an academic local project this demonstrates an appropriate password-storage concept, but a production application would normally add further controls such as account lockout/rate limiting, CSRF protection, audit logging, secure cookies and HTTPS.

## Scope

This is a **small academic project**, not a production enterprise platform. Its goal is to demonstrate Advanced Java concepts through working features rather than cloud deployment or a large framework.
