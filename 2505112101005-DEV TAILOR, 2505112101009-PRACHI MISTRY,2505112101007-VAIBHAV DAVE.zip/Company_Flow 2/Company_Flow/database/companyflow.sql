CREATE DATABASE IF NOT EXISTS companyflow;
USE companyflow;

DROP TABLE IF EXISTS tasks;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(400) NOT NULL,
    role ENUM('ADMIN','EMPLOYEE') NOT NULL DEFAULT 'EMPLOYEE',
    department VARCHAR(100) NOT NULL DEFAULT 'General',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    assigned_to INT NOT NULL,
    status ENUM('PENDING','IN_PROGRESS','COMPLETED') NOT NULL DEFAULT 'PENDING',
    due_date DATE NULL,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_task_assignee FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_task_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE RESTRICT
);

-- Demo administrator. Password: Admin@123
-- PBKDF2-HMAC-SHA256: 120000 iterations, salt is encoded inside password_hash.
INSERT INTO users (full_name, email, password_hash, role, department)
VALUES (
    'System Administrator',
    'admin@companyflow.local',
    'pbkdf2$120000$QWRtaW5Db21wYW55U2FsdA==$KIZ7GT3f3umQD2cO+dmalny3oPnEtVbFuKAh0bI57Ws=',
    'ADMIN',
    'Management'
);

-- Demo employee. Password: Employee@123
-- PBKDF2-HMAC-SHA256: 120000 iterations, unique salt encoded inside password_hash.
INSERT INTO users (full_name, email, password_hash, role, department)
VALUES (
    'Demo Employee',
    'employee@companyflow.local',
    'pbkdf2$120000$RW1wbG95ZWVDb21wYW55U2E=$enxpIM64zUfUECGrW+vlhMcDE1alIUixoNwfyN8+fq4=',
    'EMPLOYEE',
    'Engineering'
);

-- Demo tasks assigned to the demo employee (employee id = 2, admin id = 1).
-- The admin can create unlimited additional tasks from the Task Management page.
INSERT INTO tasks (title, description, assigned_to, status, due_date, created_by) VALUES
('Prepare weekly project report', 'Create the weekly status report and mark the task completed from the employee dashboard.', 2, 'PENDING', DATE_ADD(CURRENT_DATE, INTERVAL 3 DAY), 1),
('Validate registration form', 'Review company registration validation rules and confirm required fields.', 2, 'IN_PROGRESS', DATE_ADD(CURRENT_DATE, INTERVAL 2 DAY), 1),
('Test login authentication', 'Verify employee and admin login, logout and session protection.', 2, 'PENDING', DATE_ADD(CURRENT_DATE, INTERVAL 5 DAY), 1),
('Update employee records', 'Check employee information and confirm the CRUD workflow is working correctly.', 2, 'PENDING', DATE_ADD(CURRENT_DATE, INTERVAL 7 DAY), 1),
('Review dashboard UI', 'Review dashboard layout, statistics and task checklist presentation.', 2, 'COMPLETED', CURRENT_DATE, 1),
('Database connectivity test', 'Confirm JDBC connection and verify data is stored and retrieved from MySQL.', 2, 'COMPLETED', CURRENT_DATE, 1);
