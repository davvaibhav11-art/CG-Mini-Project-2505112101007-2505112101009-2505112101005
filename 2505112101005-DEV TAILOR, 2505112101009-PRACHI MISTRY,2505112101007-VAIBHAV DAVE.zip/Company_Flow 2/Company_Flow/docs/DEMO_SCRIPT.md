# CompanyFlow — Live Demo Script

## 1. Start the stack
- Start MySQL in XAMPP.
- Start Apache Tomcat from NetBeans.
- Open `http://localhost:8080/CompanyFlow/`.

## 2. Registration
Open **Create an account** and register an employee:

```text
Name:      Demo Employee
Email:     employee@example.com
Department: Engineering
Password:  Employee@123
```

Explain:
> "This form is processed by RegisterServlet. Server-side validation runs before JDBC inserts the record into MySQL."

## 3. Login
Use the new employee credentials.

Explain:
> "LoginServlet checks the entered credentials against the users table. When authentication succeeds, an HTTP session stores the user ID, name, email and role."

## 4. Filter demonstration
Try opening `/admin/dashboard` while logged in as an employee.

Explain:
> "The AuthFilter checks whether a session exists. The AdminFilter then checks the user's role. An employee is redirected to the employee dashboard instead of receiving admin access."

## 5. Admin login
Log out and use:

```text
admin@companyflow.local
Admin@123
```

## 6. User CRUD
Open **Users**.
- Add a user.
- Edit a user.
- Search by name/email/department.
- Delete a test user.

Explain:
> "PreparedStatement is used in the DAO layer for database operations."

## 7. Task assignment
Open **Tasks** and create:

```text
Title:      Build login module
Employee:   Demo Employee
Due date:   choose a date
Description: Implement and test the local login workflow.
```

Explain:
> "The administrator assigns work to an employee. The task record stores the assignee, creator, status and due date."

## 8. Employee checkbox
Log out → log in as Demo Employee → open **My Work**.

Click the checkbox beside the assigned task.

Explain:
> "The checkbox submits the task ID to EmployeeTaskStatusServlet. The servlet updates only the logged-in employee's own task, changing the status to COMPLETED."

The dashboard should update:

```text
Assigned: 1
Completed: 1
Remaining: 0
Completion: 100%
```

## 9. Final explanation
Say:
> "This project demonstrates a complete local Java web application using JSP, Servlets, Filters, JDBC and MySQL. It includes authentication, authorization, CRUD operations, validation and a simple employee task workflow, without requiring any live deployment."
