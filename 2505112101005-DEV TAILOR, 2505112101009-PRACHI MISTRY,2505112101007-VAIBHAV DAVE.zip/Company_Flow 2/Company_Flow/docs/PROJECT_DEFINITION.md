# CompanyFlow — Project Definition

## Title
**CompanyFlow: Local Company Registration & Task Management System**

## Definition
CompanyFlow is a web-based Advanced Java mini project that models a small company's employee registration and work-management process. The application allows employees to create accounts and authenticate through a local MySQL database. An administrator can maintain employee records, create and assign tasks, change task information, search records, and monitor completed versus remaining work. Employees can view their assigned tasks and use a checklist to update their work status.

## Technologies
- Java 17+ source compatibility
- JSP (JavaServer Pages)
- Java Servlets
- Servlet Filters
- JDBC
- MySQL
- HTML/CSS/JavaScript for the presentation layer
- Apache Tomcat 10.1.x
- Apache NetBeans for development and deployment

## Functional Modules
1. Registration
2. Login
3. Logout
4. Authentication Filter
5. Admin Authorization Filter
6. User CRUD
7. User Search
8. Task CRUD
9. Task Search
10. Admin Task Assignment
11. Employee Task Checklist
12. Validation
13. MySQL database persistence
14. Dashboard statistics

## Completed vs Remaining Work

| Feature | Included |
|---|---|
| Registration | Yes |
| Login / Logout | Yes |
| Database | Yes |
| Servlets | Yes |
| JSP | Yes |
| Authentication Filter | Yes |
| Admin Filter | Yes |
| Input Validation | Yes |
| Admin User | Yes |
| User Insert | Yes |
| User Update | Yes |
| User Delete | Yes |
| User Search | Yes |
| Task Insert | Yes |
| Task Update | Yes |
| Task Delete | Yes |
| Task Search | Yes |
| Admin Task Assignment | Yes |
| Completion Checkbox | Yes |
| Completed / Remaining Counters | Yes |
| Local-only deployment | Yes |

## Why the project is suitable for Advanced Java
The application demonstrates the complete flow of a Java web request:

**Browser → JSP → Servlet → Filter / Session → DAO → JDBC → MySQL → Response**

This provides a clear practical demonstration of the major syllabus concepts without introducing unnecessary frameworks.
