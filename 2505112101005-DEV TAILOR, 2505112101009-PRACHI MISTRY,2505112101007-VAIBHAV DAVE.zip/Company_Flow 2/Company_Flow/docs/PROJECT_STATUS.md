# Project Status Checklist

- [x] Registration page
- [x] Login / logout
- [x] MySQL database
- [x] JSP views
- [x] Servlets
- [x] Authentication Filter
- [x] Admin authorization Filter
- [x] Server-side validation
- [x] Admin user
- [x] User insert / update / delete / search
- [x] Task insert / update / delete / search
- [x] Admin task assignment
- [x] Employee task checklist
- [x] Completed / remaining counters
- [x] Professional local UI
- [x] NetBeans-friendly Maven structure
- [x] Setup and live-demo guide

## Remaining / optional enhancements

These are intentionally outside the tiny-project scope:

- Email notifications
- File uploads
- Cloud deployment
- REST API
- Role/permission builder
- Audit log
- CSRF protection
- Account lockout / rate limiting
