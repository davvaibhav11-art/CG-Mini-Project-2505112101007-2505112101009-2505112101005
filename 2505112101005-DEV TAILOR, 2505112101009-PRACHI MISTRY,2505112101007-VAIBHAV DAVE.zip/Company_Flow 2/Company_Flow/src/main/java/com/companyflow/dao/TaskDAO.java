package com.companyflow.dao;

import com.companyflow.model.Task;
import com.companyflow.util.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TaskDAO {
    public void create(Task task, int createdBy) throws SQLException {
        String sql = "INSERT INTO tasks(title,description,assigned_to,status,due_date,created_by) VALUES(?,?,?,?,?,?)";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            fill(ps, task); ps.setInt(6, createdBy); ps.executeUpdate();
        }
    }

    public List<Task> findAll(String search) throws SQLException {
        List<Task> tasks = new ArrayList<>();
        String sql = "SELECT t.*, u.full_name assignee_name FROM tasks t JOIN users u ON u.id=t.assigned_to " +
                "WHERE t.title LIKE ? OR t.status LIKE ? OR u.full_name LIKE ? ORDER BY t.id DESC";
        String q = "%" + (search == null ? "" : search.trim()) + "%";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, q); ps.setString(2, q); ps.setString(3, q);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) tasks.add(map(rs)); }
        }
        return tasks;
    }

    public Task findById(int id) throws SQLException {
        String sql = "SELECT t.*, u.full_name assignee_name FROM tasks t JOIN users u ON u.id=t.assigned_to WHERE t.id=?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? map(rs) : null; }
        }
    }

    public void update(Task task) throws SQLException {
        String sql = "UPDATE tasks SET title=?,description=?,assigned_to=?,status=?,due_date=? WHERE id=?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            fill(ps, task); ps.setInt(6, task.getId()); ps.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement("DELETE FROM tasks WHERE id=?")) {
            ps.setInt(1, id); ps.executeUpdate();
        }
    }

    public List<Task> findForEmployee(int employeeId, String search) throws SQLException {
        List<Task> tasks = new ArrayList<>();
        String sql = "SELECT t.*, u.full_name assignee_name FROM tasks t JOIN users u ON u.id=t.assigned_to " +
                "WHERE t.assigned_to=? AND (t.title LIKE ? OR t.status LIKE ?) ORDER BY t.status='COMPLETED', t.due_date IS NULL, t.due_date, t.id DESC";
        String q = "%" + (search == null ? "" : search.trim()) + "%";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, employeeId); ps.setString(2, q); ps.setString(3, q);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) tasks.add(map(rs)); }
        }
        return tasks;
    }

    public void updateStatusForEmployee(int taskId, int employeeId, String status) throws SQLException {
        String sql = "UPDATE tasks SET status=? WHERE id=? AND assigned_to=?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, status); ps.setInt(2, taskId); ps.setInt(3, employeeId); ps.executeUpdate();
        }
    }

    public int countAll() throws SQLException { return count("SELECT COUNT(*) FROM tasks"); }
    public int countByStatus(String status) throws SQLException {
        String sql = "SELECT COUNT(*) FROM tasks WHERE status=?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, status); try (ResultSet rs = ps.executeQuery()) { rs.next(); return rs.getInt(1); }
        }
    }

    public int countForEmployee(int employeeId, String status) throws SQLException {
        String sql = status == null ? "SELECT COUNT(*) FROM tasks WHERE assigned_to=?" : "SELECT COUNT(*) FROM tasks WHERE assigned_to=? AND status=?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, employeeId);
            if (status != null) ps.setString(2, status);
            try (ResultSet rs = ps.executeQuery()) { rs.next(); return rs.getInt(1); }
        }
    }

    private int count(String sql) throws SQLException {
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) { rs.next(); return rs.getInt(1); }
    }

    private void fill(PreparedStatement ps, Task task) throws SQLException {
        ps.setString(1, task.getTitle());
        ps.setString(2, task.getDescription());
        ps.setInt(3, task.getAssignedTo());
        ps.setString(4, task.getStatus());
        if (task.getDueDate() == null) ps.setNull(5, Types.DATE); else ps.setDate(5, Date.valueOf(task.getDueDate()));
    }

    private Task map(ResultSet rs) throws SQLException {
        Task t = new Task();
        t.setId(rs.getInt("id"));
        t.setTitle(rs.getString("title"));
        t.setDescription(rs.getString("description"));
        t.setAssignedTo(rs.getInt("assigned_to"));
        t.setAssigneeName(rs.getString("assignee_name"));
        t.setStatus(rs.getString("status"));
        Date d = rs.getDate("due_date");
        t.setDueDate(d == null ? null : d.toLocalDate());
        return t;
    }
}
