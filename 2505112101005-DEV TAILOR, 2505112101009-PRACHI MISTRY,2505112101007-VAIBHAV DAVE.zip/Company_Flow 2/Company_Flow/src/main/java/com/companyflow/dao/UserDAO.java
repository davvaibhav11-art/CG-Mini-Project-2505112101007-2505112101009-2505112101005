package com.companyflow.dao;

import com.companyflow.model.User;
import com.companyflow.util.DBConnection;
import com.companyflow.util.PasswordUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {
    public User authenticate(String email, String password) throws SQLException {
        String sql = "SELECT * FROM users WHERE email = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next() && PasswordUtil.verifyPassword(password, rs.getString("password_hash"))) {
                    return map(rs);
                }
            }
        }
        return null;
    }

    public void create(User user) throws SQLException {
        String sql = "INSERT INTO users(full_name,email,password_hash,role,department) VALUES(?,?,?,?,?)";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, user.getFullName());
            ps.setString(2, user.getEmail());
            ps.setString(3, PasswordUtil.hashPassword(user.getPasswordHash()));
            ps.setString(4, user.getRole());
            ps.setString(5, user.getDepartment());
            ps.executeUpdate();
        }
    }

    public List<User> findAll(String search) throws SQLException {
        List<User> users = new ArrayList<>();
        String sql = "SELECT id,full_name,email,role,department FROM users " +
                "WHERE full_name LIKE ? OR email LIKE ? OR department LIKE ? ORDER BY id DESC";
        String q = "%" + (search == null ? "" : search.trim()) + "%";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, q); ps.setString(2, q); ps.setString(3, q);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) users.add(map(rs));
            }
        }
        return users;
    }

    public User findById(int id) throws SQLException {
        String sql = "SELECT id,full_name,email,role,department FROM users WHERE id=?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    public void update(User user, String newPassword) throws SQLException {
        String sql = newPassword == null || newPassword.isBlank()
                ? "UPDATE users SET full_name=?, email=?, role=?, department=? WHERE id=?"
                : "UPDATE users SET full_name=?, email=?, role=?, department=?, password_hash=? WHERE id=?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, user.getFullName());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getRole());
            ps.setString(4, user.getDepartment());
            if (newPassword == null || newPassword.isBlank()) {
                ps.setInt(5, user.getId());
            } else {
                ps.setString(5, PasswordUtil.hashPassword(newPassword));
                ps.setInt(6, user.getId());
            }
            ps.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM users WHERE id=?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public int countEmployees() throws SQLException {
        return countByRole("EMPLOYEE");
    }

    public int countAdmins() throws SQLException {
        return countByRole("ADMIN");
    }

    public List<User> findEmployees() throws SQLException {
        List<User> employees = new ArrayList<>();
        String sql = "SELECT id,full_name,email,role,department FROM users WHERE role='EMPLOYEE' ORDER BY full_name";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) employees.add(map(rs));
        }
        return employees;
    }

    private int countByRole(String role) throws SQLException {
        String sql = "SELECT COUNT(*) FROM users WHERE role=?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, role);
            try (ResultSet rs = ps.executeQuery()) { rs.next(); return rs.getInt(1); }
        }
    }

    private User map(ResultSet rs) throws SQLException {
        User u = new User();
        u.setId(rs.getInt("id"));
        u.setFullName(rs.getString("full_name"));
        u.setEmail(rs.getString("email"));
        u.setRole(rs.getString("role"));
        u.setDepartment(rs.getString("department"));
        if (hasColumn(rs, "password_hash")) u.setPasswordHash(rs.getString("password_hash"));
        return u;
    }

    private boolean hasColumn(ResultSet rs, String name) throws SQLException {
        ResultSetMetaData md = rs.getMetaData();
        for (int i = 1; i <= md.getColumnCount(); i++) if (md.getColumnLabel(i).equalsIgnoreCase(name)) return true;
        return false;
    }
}
