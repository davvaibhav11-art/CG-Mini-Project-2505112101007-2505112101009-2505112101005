package com.companyflow.filter;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebFilter(urlPatterns = {"/admin/*"})
public class AdminFilter implements Filter {
    @Override public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        HttpSession session = req.getSession(false);
        Object role = session == null ? null : session.getAttribute("userRole");
        if (!"ADMIN".equals(role)) {
            resp.sendRedirect(req.getContextPath() + "/employee/dashboard");
            return;
        }
        chain.doFilter(request, response);
    }
}
