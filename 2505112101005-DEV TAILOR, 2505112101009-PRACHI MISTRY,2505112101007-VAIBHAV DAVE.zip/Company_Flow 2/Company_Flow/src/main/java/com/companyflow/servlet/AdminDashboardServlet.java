package com.companyflow.servlet;

import com.companyflow.dao.TaskDAO;
import com.companyflow.dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/admin/dashboard")
public class AdminDashboardServlet extends HttpServlet {
    private final UserDAO users = new UserDAO();
    private final TaskDAO tasks = new TaskDAO();

    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            req.setAttribute("employees", users.countEmployees());
            req.setAttribute("admins", users.countAdmins());
            req.setAttribute("tasks", tasks.countAll());
            req.setAttribute("completed", tasks.countByStatus("COMPLETED"));
            req.setAttribute("remaining", tasks.countAll() - tasks.countByStatus("COMPLETED"));
            req.setAttribute("taskList", tasks.findAll(""));
            req.getRequestDispatcher("/WEB-INF/views/admin/dashboard.jsp").forward(req, resp);
        } catch (Exception e) {
            throw new ServletException("Unable to load dashboard.", e);
        }
    }
}
