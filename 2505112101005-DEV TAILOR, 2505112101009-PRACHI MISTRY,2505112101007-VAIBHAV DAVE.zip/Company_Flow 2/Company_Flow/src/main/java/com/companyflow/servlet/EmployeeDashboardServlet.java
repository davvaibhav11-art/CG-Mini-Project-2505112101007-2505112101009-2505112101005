package com.companyflow.servlet;

import com.companyflow.dao.TaskDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/employee/dashboard")
public class EmployeeDashboardServlet extends HttpServlet {
    private final TaskDAO tasks = new TaskDAO();

    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int userId = (Integer) req.getSession().getAttribute("userId");
        try {
            req.setAttribute("taskList", tasks.findForEmployee(userId, ""));
            req.setAttribute("total", tasks.countForEmployee(userId, null));
            req.setAttribute("completed", tasks.countForEmployee(userId, "COMPLETED"));
            req.setAttribute("remaining", (Integer) req.getAttribute("total") - (Integer) req.getAttribute("completed"));
            req.getRequestDispatcher("/WEB-INF/views/employee/dashboard.jsp").forward(req, resp);
        } catch (Exception e) {
            throw new ServletException("Unable to load employee dashboard.", e);
        }
    }
}
