package com.companyflow.servlet;

import com.companyflow.dao.TaskDAO;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/employee/tasks/status")
public class EmployeeTaskStatusServlet extends HttpServlet {
    private final TaskDAO dao = new TaskDAO();
    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        int userId = (Integer) req.getSession().getAttribute("userId");
        try {
            int taskId = Integer.parseInt(req.getParameter("taskId"));
            String status = "on".equals(req.getParameter("completed")) ? "COMPLETED" : "IN_PROGRESS";
            dao.updateStatusForEmployee(taskId, userId, status);
        } catch (Exception ignored) {}
        resp.sendRedirect(req.getContextPath() + "/employee/dashboard");
    }
}
