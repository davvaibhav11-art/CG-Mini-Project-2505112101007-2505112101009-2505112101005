package com.companyflow.servlet;

import com.companyflow.dao.UserDAO;
import com.companyflow.model.User;
import com.companyflow.util.ValidationUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private final UserDAO userDAO = new UserDAO();

    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/login.jsp").forward(req, resp);
    }

    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String email = ValidationUtil.clean(req.getParameter("email"));
        String password = req.getParameter("password");
        if (email.isBlank() || password == null || password.isBlank()) {
            req.setAttribute("error", "Email and password are required.");
            req.getRequestDispatcher("/login.jsp").forward(req, resp); return;
        }
        try {
            User user = userDAO.authenticate(email, password);
            if (user == null) {
                req.setAttribute("error", "Invalid email or password.");
                req.getRequestDispatcher("/login.jsp").forward(req, resp); return;
            }
            HttpSession session = req.getSession(true);
            session.setAttribute("userId", user.getId());
            session.setAttribute("userName", user.getFullName());
            session.setAttribute("userRole", user.getRole());
            session.setAttribute("userEmail", user.getEmail());
            String context = req.getContextPath();
            resp.sendRedirect(context + ("ADMIN".equals(user.getRole()) ? "/admin/dashboard" : "/employee/dashboard"));
        } catch (Exception e) {
            req.setAttribute("error", "Database connection failed. Start MySQL and import database/companyflow.sql.");
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
        }
    }
}
