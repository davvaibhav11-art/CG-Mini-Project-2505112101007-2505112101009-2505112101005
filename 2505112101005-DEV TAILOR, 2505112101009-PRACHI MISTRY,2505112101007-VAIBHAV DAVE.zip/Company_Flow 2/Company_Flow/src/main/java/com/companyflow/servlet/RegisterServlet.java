package com.companyflow.servlet;

import com.companyflow.dao.UserDAO;
import com.companyflow.model.User;
import com.companyflow.util.ValidationUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    private final UserDAO userDAO = new UserDAO();

    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/register.jsp").forward(req, resp);
    }

    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = ValidationUtil.clean(req.getParameter("fullName"));
        String email = ValidationUtil.clean(req.getParameter("email")).toLowerCase();
        String password = req.getParameter("password");
        String confirm = req.getParameter("confirmPassword");
        String department = ValidationUtil.clean(req.getParameter("department"));

        if (password == null) password = "";
        String error = ValidationUtil.validateRegistration(name, email, password, department);
        if (error == null && !password.equals(confirm)) error = "Passwords do not match.";
        if (error != null) {
            req.setAttribute("error", error);
            req.getRequestDispatcher("/register.jsp").forward(req, resp); return;
        }

        User user = new User();
        user.setFullName(name); user.setEmail(email); user.setPasswordHash(password);
        user.setRole("EMPLOYEE"); user.setDepartment(department);
        try {
            userDAO.create(user);
            req.setAttribute("success", "Registration successful. You can now sign in.");
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
        } catch (Exception e) {
            String msg = e.getMessage() != null && e.getMessage().contains("Duplicate")
                    ? "An account with that email already exists." : "Unable to create account. Check the database connection.";
            req.setAttribute("error", msg);
            req.getRequestDispatcher("/register.jsp").forward(req, resp);
        }
    }
}
