package com.companyflow.servlet;

import com.companyflow.dao.TaskDAO;
import com.companyflow.dao.UserDAO;
import com.companyflow.model.Task;
import com.companyflow.util.ValidationUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.time.LocalDate;

@WebServlet("/admin/tasks")
public class TaskServlet extends HttpServlet {
    private final TaskDAO dao = new TaskDAO();
    private final UserDAO users = new UserDAO();

    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            req.setAttribute("tasks", dao.findAll(req.getParameter("q")));
            req.setAttribute("employees", users.findEmployees());
            if ("edit".equals(req.getParameter("action"))) req.setAttribute("editTask", dao.findById(Integer.parseInt(req.getParameter("id"))));
            req.getRequestDispatcher("/WEB-INF/views/admin/tasks.jsp").forward(req, resp);
        } catch (Exception e) { throw new ServletException("Unable to load tasks.", e); }
    }

    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        try {
            if ("delete".equals(action)) {
                dao.delete(Integer.parseInt(req.getParameter("id")));
            } else {
                String title = ValidationUtil.clean(req.getParameter("title"));
                String description = ValidationUtil.clean(req.getParameter("description"));
                String assignee = ValidationUtil.clean(req.getParameter("assignedTo"));
                String due = ValidationUtil.clean(req.getParameter("dueDate"));
                String error = ValidationUtil.validateTask(title, description, assignee, due);
                if ("update".equals(action) && !ListStatus.isValid(req.getParameter("status"))) error = "Invalid status.";
                if (error != null) { req.setAttribute("error", error); doGet(req, resp); return; }
                Task t = new Task();
                t.setTitle(title); t.setDescription(description); t.setAssignedTo(Integer.parseInt(assignee));
                t.setStatus(ListStatus.normalize(req.getParameter("status")));
                t.setDueDate(due.isBlank() ? null : LocalDate.parse(due));
                if ("update".equals(action)) { t.setId(Integer.parseInt(req.getParameter("id"))); dao.update(t); }
                else dao.create(t, (Integer) req.getSession().getAttribute("userId"));
            }
            resp.sendRedirect(req.getContextPath() + "/admin/tasks?message=success");
        } catch (Exception e) {
            req.setAttribute("error", "Unable to save task. Check the selected employee and database connection.");
            doGet(req, resp);
        }
    }

    private static class ListStatus {
        static boolean isValid(String s) { return "PENDING".equals(s) || "IN_PROGRESS".equals(s) || "COMPLETED".equals(s); }
        static String normalize(String s) { return isValid(s) ? s : "PENDING"; }
    }
}
