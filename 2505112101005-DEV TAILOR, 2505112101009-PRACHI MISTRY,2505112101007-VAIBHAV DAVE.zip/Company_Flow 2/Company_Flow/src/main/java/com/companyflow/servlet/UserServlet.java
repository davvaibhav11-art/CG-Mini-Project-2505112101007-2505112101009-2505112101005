package com.companyflow.servlet;

import com.companyflow.dao.UserDAO;
import com.companyflow.model.User;
import com.companyflow.util.ValidationUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.List;

@WebServlet("/admin/users")
public class UserServlet extends HttpServlet {
    private final UserDAO dao = new UserDAO();

    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            req.setAttribute("users", dao.findAll(req.getParameter("q")));
            String action = req.getParameter("action");
            if ("edit".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                req.setAttribute("editUser", dao.findById(id));
            }
            req.getRequestDispatcher("/WEB-INF/views/admin/users.jsp").forward(req, resp);
        } catch (Exception e) { throw new ServletException("Unable to load users.", e); }
    }

    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        try {
            if ("delete".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                int currentId = (Integer) req.getSession().getAttribute("userId");
                if (id == currentId) { resp.sendRedirect(req.getContextPath() + "/admin/users?message=self"); return; }
                else dao.delete(id);
            } else {
                int id = parseId(req.getParameter("id"));
                String name = ValidationUtil.clean(req.getParameter("fullName"));
                String email = ValidationUtil.clean(req.getParameter("email")).toLowerCase();
                String password = req.getParameter("password");
                String role = "ADMIN".equals(req.getParameter("role")) ? "ADMIN" : "EMPLOYEE";
                String department = ValidationUtil.clean(req.getParameter("department"));
                String error = id > 0
                        ? validateUserUpdate(name, email, department, password)
                        : ValidationUtil.validateRegistration(name, email, password == null ? "" : password, department);
                if (error == null && id > 0) {
                    User u = new User(); u.setId(id); u.setFullName(name); u.setEmail(email); u.setRole(role); u.setDepartment(department);
                    dao.update(u, password);
                } else if (error == null) {
                    User u = new User(); u.setFullName(name); u.setEmail(email); u.setPasswordHash(password); u.setRole(role); u.setDepartment(department);
                    dao.create(u);
                } else {
                    req.setAttribute("error", error);
                    doGet(req, resp); return;
                }
            }
            resp.sendRedirect(req.getContextPath() + "/admin/users?message=success");
        } catch (Exception e) {
            req.setAttribute("error", e.getMessage() != null && e.getMessage().contains("Duplicate") ? "Email already exists." : "Unable to save user.");
            doGet(req, resp);
        }
    }

    private String validateUserUpdate(String name, String email, String department, String password) {
        String error = ValidationUtil.validateRegistration(name, email, password == null || password.isBlank() ? "temporary" : password, department);
        if (password == null || password.isBlank()) {
            // Blank password is permitted on edit, meaning keep the existing password.
            if (name.length() < 2 || name.length() > 100) return "Name must contain 2-100 characters.";
            if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) return "Enter a valid email address.";
            if (department.length() < 2 || department.length() > 100) return "Department must contain 2-100 characters.";
            return null;
        }
        return error;
    }

    private int parseId(String value) { try { return Integer.parseInt(value); } catch (Exception e) { return 0; } }
}
