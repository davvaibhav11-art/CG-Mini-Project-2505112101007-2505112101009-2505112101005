package com.companyflow.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class DBConnection {
    private static final String URL =
    "jdbc:mysql://localhost:3308/companyflow?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Kolkata";
    //private static final String URL = "jdbc:mysql://localhost:3306/companyflow?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Kolkata";
    private static final String USER = envOrDefault("COMPANYFLOW_DB_USER", "root");
    private static final String PASSWORD = envOrDefault("COMPANYFLOW_DB_PASSWORD", "");

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new IllegalStateException("MySQL Connector/J is missing from the application.", e);
        }
    }

    private DBConnection() {}

    private static String envOrDefault(String key, String fallback) {
        String value = System.getenv(key);
        return value == null || value.isBlank() ? fallback : value;
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
