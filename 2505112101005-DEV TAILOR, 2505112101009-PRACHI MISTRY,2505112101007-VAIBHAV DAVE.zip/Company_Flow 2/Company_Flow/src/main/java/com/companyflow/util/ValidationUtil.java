package com.companyflow.util;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.regex.Pattern;

public final class ValidationUtil {
    private static final Pattern EMAIL = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");

    private ValidationUtil() {}

    public static String clean(String input) {
        return input == null ? "" : input.trim();
    }

    public static String validateRegistration(String name, String email, String password, String department) {
        if (name.length() < 2 || name.length() > 100) return "Name must contain 2-100 characters.";
        if (!EMAIL.matcher(email).matches()) return "Enter a valid email address.";
        if (password.length() < 8) return "Password must contain at least 8 characters.";
        if (department.length() < 2 || department.length() > 100) return "Department must contain 2-100 characters.";
        return null;
    }

    public static String validateTask(String title, String description, String assigneeId, String dueDate) {
        if (title.length() < 3 || title.length() > 150) return "Task title must contain 3-150 characters.";
        if (description.length() > 2000) return "Description is too long.";
        try {
            int id = Integer.parseInt(assigneeId);
            if (id <= 0) return "Select a valid employee.";
        } catch (NumberFormatException e) {
            return "Select a valid employee.";
        }
        if (!dueDate.isBlank()) {
            try { LocalDate.parse(dueDate); } catch (DateTimeParseException e) { return "Due date is invalid."; }
        }
        return null;
    }
}
