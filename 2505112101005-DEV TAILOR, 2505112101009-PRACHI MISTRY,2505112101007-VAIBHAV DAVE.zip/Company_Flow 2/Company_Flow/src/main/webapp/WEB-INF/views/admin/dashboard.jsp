<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html><html><head><title>Admin Dashboard | CompanyFlow</title><link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css"></head>
<body><div class="app">
<aside class="sidebar"><div class="brand"><h1>CompanyFlow</h1><p>Admin workspace</p></div><nav class="nav">
<a class="active" href="${pageContext.request.contextPath}/admin/dashboard">Dashboard</a>
<a href="${pageContext.request.contextPath}/admin/users">Users</a>
<a href="${pageContext.request.contextPath}/admin/tasks">Tasks</a>
<a href="${pageContext.request.contextPath}/logout">Logout</a>
</nav><div class="side-foot">Local Tomcat application<br>JSP • Servlet • Filter • JDBC</div></aside>
<main class="main"><header class="topbar"><div class="title">Admin Dashboard</div><div class="user-box"><div class="avatar">${sessionScope.userName.substring(0,1)}</div><div><strong>${sessionScope.userName}</strong><div class="mini">Administrator</div></div></div></header>
<div class="content">
<div class="hero"><h2>Manage the company workspace.</h2><p>Monitor employees, assign work, update task status, and keep the local registration system organized.</p></div>
<div class="cards">
<div class="card"><div class="stat-label">Employees</div><div class="stat">${employees}</div><div class="card-foot">Active employee records</div></div>
<div class="card"><div class="stat-label">Administrators</div><div class="stat">${admins}</div><div class="card-foot">Privileged accounts</div></div>
<div class="card"><div class="stat-label">Total Tasks</div><div class="stat">${tasks}</div><div class="card-foot">All assigned work</div></div>
<div class="card"><div class="stat-label">Completed</div><div class="stat">${completed}</div><div class="card-foot">Finished tasks</div></div>
</div>
<div class="quick-actions">
  <div class="section-head"><h3>Quick actions</h3><span class="mini">Admin shortcuts</span></div>
  <div class="quick-action-body">
    <a class="quick-action" href="${pageContext.request.contextPath}/admin/users"><span class="qa-icon">+</span><span><strong>Add employee</strong><small>Create a new user account</small></span></a>
    <a class="quick-action" href="${pageContext.request.contextPath}/admin/tasks"><span class="qa-icon">✓</span><span><strong>Assign a task</strong><small>Create and assign new work</small></span></a>
  </div>
</div>
<div class="section"><div class="section-head"><h3>Work overview</h3><div class="task-progress"><span class="muted">${completed} completed / ${remaining} remaining</span><div class="progress"><span style="width:${tasks == 0 ? 0 : completed * 100 / tasks}%"></span></div></div></div>
<div class="section-body table-wrap"><table><thead><tr><th>Task</th><th>Assigned To</th><th>Status</th><th>Due Date</th></tr></thead><tbody>
<c:forEach var="t" items="${taskList}" begin="0" end="6"><tr><td><strong>${t.title}</strong><div class="mini">${t.description}</div></td><td>${t.assigneeName}</td><td><span class="pill ${t.status == 'COMPLETED' ? 'green' : (t.status == 'IN_PROGRESS' ? 'amber' : 'blue')}">${t.status}</span></td><td>${t.dueDate == null ? '—' : t.dueDate}</td></tr></c:forEach>
<c:if test="${empty taskList}"><tr><td colspan="4" class="empty">No tasks have been created yet.</td></tr></c:if>
</tbody></table></div></div>
</div></main></div><script src="${pageContext.request.contextPath}/assets/app.js"></script></body></html>
