<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html><head><title>CompanyFlow</title><link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css"></head>
<body>
<div class="landing"><div class="landing-card"><div class="landing-grid">
  <div>
    <div class="mini">ADVANCED JAVA • LOCAL WEB APPLICATION</div>
    <h1>Company<span>Flow</span></h1>
    <p>A professional local company registration and task management system built with JSP, Servlets, Filters, JDBC and MySQL.</p>
    <div class="feature-list">
      <div class="feature"><strong>Registration</strong>Employee account creation</div>
      <div class="feature"><strong>Authentication</strong>Real login / logout with sessions</div>
      <div class="feature"><strong>Admin Control</strong>User and task management</div>
      <div class="feature"><strong>Task Tracking</strong>Assign, update and complete work</div>
      <div class="feature"><strong>Validation</strong>Server-side input checks</div>
      <div class="feature"><strong>Database</strong>MySQL + JDBC persistence</div>
    </div>
    <a class="btn btn-primary" href="${pageContext.request.contextPath}/login">Open Local Application →</a>
  </div>
  <div class="section" style="margin:0"><div class="section-body">
    <div class="mini">SYSTEM COMPONENTS</div>
    <div class="code" style="margin-top:12px">Browser
   ↓
JSP View
   ↓
Servlet Controller
   ↓
Filter / Session Check
   ↓
DAO + JDBC
   ↓
MySQL Database</div>
    <div class="footer-note">Designed for academic demonstration on Apache Tomcat. No live deployment required.</div>
  </div></div>
</div></div></div>
</body></html>
