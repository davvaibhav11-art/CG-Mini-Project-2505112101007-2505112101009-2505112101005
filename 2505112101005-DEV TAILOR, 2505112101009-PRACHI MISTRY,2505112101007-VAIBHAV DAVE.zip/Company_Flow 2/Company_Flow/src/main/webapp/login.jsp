<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html><html><head><title>Sign In | CompanyFlow</title><link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css"></head>
<body><div class="auth-page"><div class="auth-card">
  <div class="auth-brand"><div class="mini">COMPANYFLOW</div><h1>Sign in</h1><p>Access your local company workspace</p></div>
  <% if(request.getAttribute("error") != null){ %><div class="alert error" data-auto-dismiss><%= request.getAttribute("error") %></div><% } %>
  <% if(request.getAttribute("success") != null){ %><div class="alert success" data-auto-dismiss><%= request.getAttribute("success") %></div><% } %>
  <% if("1".equals(request.getParameter("logout"))){ %><div class="alert success" data-auto-dismiss>You have been logged out successfully.</div><% } %>
  <form action="${pageContext.request.contextPath}/login" method="post">
    <div class="form-grid">
      <div class="field"><label>Email</label><input type="email" name="email" placeholder="you@company.com" required></div>
      <div class="field"><label>Password</label><input type="password" name="password" placeholder="Enter password" required></div>
    </div>
    <button class="btn btn-primary" style="width:100%;margin-top:18px">Sign In</button>
  </form>
  <div class="demo-box" style="margin-top:18px"><strong>Demo Admin</strong><br>admin@companyflow.local / Admin@123</div>
  <div class="auth-links">New employee? <a href="${pageContext.request.contextPath}/register">Create an account</a></div>
</div></div><script src="${pageContext.request.contextPath}/assets/app.js"></script></body></html>
