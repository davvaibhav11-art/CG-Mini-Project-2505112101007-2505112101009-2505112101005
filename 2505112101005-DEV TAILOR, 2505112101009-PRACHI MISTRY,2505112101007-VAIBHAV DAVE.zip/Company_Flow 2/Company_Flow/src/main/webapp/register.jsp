<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html><html><head><title>Registration | CompanyFlow</title><link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css"></head>
<body><div class="auth-page"><div class="auth-card" style="width:min(560px,100%)">
  <div class="auth-brand"><div class="mini">COMPANYFLOW</div><h1>Employee Registration</h1><p>Create an account for the local company workspace</p></div>
  <% if(request.getAttribute("error") != null){ %><div class="alert error"><%= request.getAttribute("error") %></div><% } %>
  <form action="${pageContext.request.contextPath}/register" method="post">
    <div class="form-grid">
      <div class="field"><label>Full name</label><input name="fullName" maxlength="100" required></div>
      <div class="field"><label>Department</label><input name="department" placeholder="Engineering, HR, Sales..." maxlength="100" required></div>
      <div class="field"><label>Email</label><input type="email" name="email" maxlength="150" required></div>
      <div class="field"><label>Password</label><input type="password" name="password" minlength="8" required></div>
      <div class="field full"><label>Confirm password</label><input type="password" name="confirmPassword" minlength="8" required></div>
    </div>
    <button class="btn btn-primary" style="width:100%;margin-top:18px">Create Employee Account</button>
  </form>
  <div class="auth-links">Already registered? <a href="${pageContext.request.contextPath}/login">Sign in</a></div>
</div></div></body></html>
