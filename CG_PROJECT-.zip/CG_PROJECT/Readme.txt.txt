====================================================
3. Project_Report.txt
Create Project_Report.txt:
========================================================
              COMPUTER GRAPHICS MINI PROJECT
========================================================

PROJECT TITLE:
ANIMATED HOME SCENE

--------------------------------------------------------
1. INTRODUCTION
--------------------------------------------------------

Computer Graphics is used to create and manipulate
visual images using computers. Animation is an important
application of Computer Graphics.

The objective of this project is to create a simple
2D animated home scene using C and OpenGL/GLUT.

The project demonstrates different graphics primitives,
transformations and animation techniques.

--------------------------------------------------------
2. OBJECTIVES
--------------------------------------------------------

The main objectives are:

- To understand basic 2D computer graphics.
- To draw objects using OpenGL.
- To understand translation and rotation.
- To create a simple animation.
- To demonstrate day and night effects.
- To implement keyboard controls.

--------------------------------------------------------
3. SOFTWARE REQUIREMENTS
--------------------------------------------------------

Programming Language:
C

IDE:
Code::Blocks

Graphics Library:
OpenGL / GLUT or freeGLUT

Operating System:
Windows

--------------------------------------------------------
4. HARDWARE REQUIREMENTS
--------------------------------------------------------

- Computer/Laptop
- Keyboard
- Minimum 2 GB RAM
- Basic graphics support

--------------------------------------------------------
5. FEATURES
--------------------------------------------------------

The project contains:

1. Animated sun
2. Moon and stars
3. Moving clouds
4. Animated person
5. Opening door
6. Rotating fan
7. House
8. Trees
9. Ground and pathway
10. Day/night transition
11. Keyboard controls

--------------------------------------------------------
6. COMPUTER GRAPHICS CONCEPTS USED
--------------------------------------------------------

A. Translation

Translation is used to move the sun, clouds and person.

B. Rotation

Rotation is used for the ceiling fan.

C. Scaling

Different sizes of circles and objects are used to create
the visual components.

D. Basic 2D Shapes

The project uses:

- Lines
- Triangles
- Quadrilaterals
- Circles

E. Animation

The objects are continuously updated using a timer
function.

--------------------------------------------------------
7. ALGORITHM
--------------------------------------------------------

Step 1:
Initialize the OpenGL window.

Step 2:
Set the 2D coordinate system.

Step 3:
Draw the sky and ground.

Step 4:
Draw the sun, clouds, trees and house.

Step 5:
Draw the person and fan.

Step 6:
Update the positions of animated objects.

Step 7:
Move the sun across the screen.

Step 8:
Change between day and night.

Step 9:
Rotate the fan continuously.

Step 10:
Move the person toward the house.

Step 11:
Open the door when the person reaches the house.

Step 12:
Repeat the animation until the program is closed.

--------------------------------------------------------
8. KEYBOARD CONTROLS
--------------------------------------------------------

S - Start animation
P - Pause animation
D - Day mode
N - Night mode
O - Open/close door
R - Reset
ESC - Exit

--------------------------------------------------------
9. RESULT
--------------------------------------------------------

The project successfully creates an animated 2D home
scene using C and OpenGL.

The project demonstrates basic Computer Graphics
concepts including drawing primitives, translation,
rotation and animation.

--------------------------------------------------------
10. CONCLUSION
--------------------------------------------------------

The Animated Home Scene project provides a simple
understanding of 2D graphics and animation.

It demonstrates how different graphical objects can be
combined to create a complete animated environment.

The project can be further improved by adding rain,
birds, vehicles, lighting effects and sound.

========================================================
                  END OF REPORT
========================================================

