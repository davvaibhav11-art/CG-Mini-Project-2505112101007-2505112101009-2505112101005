#include <GL/glut.h>
#include <math.h>
#include <stdlib.h>

/* ---------------- GLOBAL VARIABLES ---------------- */

float sunX = -0.8f;
float cloudX = -1.2f;
float personX = -1.2f;
float fanAngle = 0.0f;

float skyR = 0.35f;
float skyG = 0.70f;
float skyB = 0.95f;

int animation = 1;
int night = 0;
int doorOpen = 0;

/* ---------------- CIRCLE FUNCTION ---------------- */

void circle(float x, float y, float radius)
{
    int i;
    glBegin(GL_TRIANGLE_FAN);

    glVertex2f(x, y);

    for (i = 0; i <= 100; i++)
    {
        float angle = 2.0f * 3.14159f * i / 100.0f;
        glVertex2f(x + cos(angle) * radius,
                   y + sin(angle) * radius);
    }

    glEnd();
}

/* ---------------- CLOUD ---------------- */

void drawCloud(float x, float y)
{
    glColor3f(1.0f, 1.0f, 1.0f);

    circle(x, y, 0.10f);
    circle(x + 0.10f, y + 0.04f, 0.13f);
    circle(x + 0.22f, y, 0.10f);

    glBegin(GL_QUADS);
    glVertex2f(x - 0.05f, y - 0.08f);
    glVertex2f(x + 0.27f, y - 0.08f);
    glVertex2f(x + 0.27f, y);
    glVertex2f(x - 0.05f, y);
    glEnd();
}

/* ---------------- TREE ---------------- */

void drawTree(float x, float y)
{
    /* Trunk */
    glColor3f(0.45f, 0.22f, 0.08f);

    glBegin(GL_QUADS);
    glVertex2f(x - 0.04f, y);
    glVertex2f(x + 0.04f, y);
    glVertex2f(x + 0.04f, y + 0.30f);
    glVertex2f(x - 0.04f, y + 0.30f);
    glEnd();

    /* Leaves */
    glColor3f(0.05f, 0.50f, 0.12f);

    circle(x, y + 0.36f, 0.13f);
    circle(x - 0.10f, y + 0.30f, 0.12f);
    circle(x + 0.10f, y + 0.30f, 0.12f);
}

/* ---------------- SUN ---------------- */

void drawSun()
{
    glColor3f(1.0f, 0.75f, 0.05f);
    circle(sunX, 0.72f, 0.10f);
}

/* ---------------- MOON ---------------- */

void drawMoon()
{
    glColor3f(0.95f, 0.95f, 0.75f);
    circle(0.70f, 0.70f, 0.10f);

    /* Small dark circle to create crescent effect */
    glColor3f(skyR, skyG, skyB);
    circle(0.74f, 0.74f, 0.09f);
}

/* ---------------- STARS ---------------- */

void drawStars()
{
    glColor3f(1.0f, 1.0f, 0.8f);

    circle(-0.75f, 0.75f, 0.015f);
    circle(-0.55f, 0.60f, 0.012f);
    circle(-0.30f, 0.78f, 0.015f);
    circle(-0.05f, 0.65f, 0.012f);
    circle(0.20f, 0.80f, 0.015f);
    circle(0.45f, 0.62f, 0.012f);
    circle(0.85f, 0.78f, 0.015f);
}

/* ---------------- HOUSE ---------------- */

void drawHouse()
{
    /* House wall */
    glColor3f(0.85f, 0.55f, 0.30f);

    glBegin(GL_QUADS);
    glVertex2f(-0.45f, -0.55f);
    glVertex2f(0.45f, -0.55f);
    glVertex2f(0.45f, 0.15f);
    glVertex2f(-0.45f, 0.15f);
    glEnd();

    /* Roof */
    glColor3f(0.55f, 0.08f, 0.05f);

    glBegin(GL_TRIANGLES);
    glVertex2f(-0.55f, 0.15f);
    glVertex2f(0.55f, 0.15f);
    glVertex2f(0.0f, 0.65f);
    glEnd();

    /* Door */
    glColor3f(0.35f, 0.15f, 0.05f);

    if (!doorOpen)
    {
        glBegin(GL_QUADS);
        glVertex2f(-0.10f, -0.55f);
        glVertex2f(0.10f, -0.55f);
        glVertex2f(0.10f, -0.05f);
        glVertex2f(-0.10f, -0.05f);
        glEnd();
    }
    else
    {
        /* Open door */
        glBegin(GL_QUADS);
        glVertex2f(-0.10f, -0.55f);
        glVertex2f(-0.28f, -0.48f);
        glVertex2f(-0.28f, -0.05f);
        glVertex2f(-0.10f, -0.05f);
        glEnd();
    }

    /* Door handle */
    glColor3f(1.0f, 0.75f, 0.1f);
    circle(0.05f, -0.30f, 0.018f);

    /* Windows */
    if (night)
        glColor3f(1.0f, 0.85f, 0.25f);
    else
        glColor3f(0.30f, 0.70f, 0.90f);

    glBegin(GL_QUADS);
    glVertex2f(-0.38f, -0.10f);
    glVertex2f(-0.17f, -0.10f);
    glVertex2f(-0.17f, 0.10f);
    glVertex2f(-0.38f, 0.10f);
    glEnd();

    glBegin(GL_QUADS);
    glVertex2f(0.17f, -0.10f);
    glVertex2f(0.38f, -0.10f);
    glVertex2f(0.38f, 0.10f);
    glVertex2f(0.17f, 0.10f);
    glEnd();

    /* Window frames */
    glColor3f(0.15f, 0.10f, 0.05f);

    glBegin(GL_LINES);

    glVertex2f(-0.275f, -0.10f);
    glVertex2f(-0.275f, 0.10f);

    glVertex2f(-0.38f, 0.0f);
    glVertex2f(-0.17f, 0.0f);

    glVertex2f(0.275f, -0.10f);
    glVertex2f(0.275f, 0.10f);

    glVertex2f(0.17f, 0.0f);
    glVertex2f(0.38f, 0.0f);

    glEnd();

    /* Fan inside right window */
    glPushMatrix();

    glTranslatef(0.275f, 0.0f, 0.0f);
    glRotatef(fanAngle, 0.0f, 0.0f, 1.0f);

    glColor3f(0.15f, 0.15f, 0.15f);

    glBegin(GL_TRIANGLES);

    glVertex2f(0.0f, 0.0f);
    glVertex2f(0.13f, 0.025f);
    glVertex2f(0.05f, 0.06f);

    glVertex2f(0.0f, 0.0f);
    glVertex2f(-0.025f, 0.13f);
    glVertex2f(-0.06f, 0.05f);

    glVertex2f(0.0f, 0.0f);
    glVertex2f(-0.13f, -0.025f);
    glVertex2f(-0.05f, -0.06f);

    glVertex2f(0.0f, 0.0f);
    glVertex2f(0.025f, -0.13f);
    glVertex2f(0.06f, -0.05f);

    glEnd();

    glPopMatrix();
}

/* ---------------- PERSON ---------------- */

void drawPerson()
{
    /* Head */
    glColor3f(1.0f, 0.70f, 0.50f);
    circle(personX, -0.40f, 0.055f);

    /* Body */
    glColor3f(0.10f, 0.20f, 0.80f);

    glBegin(GL_QUADS);
    glVertex2f(personX - 0.04f, -0.65f);
    glVertex2f(personX + 0.04f, -0.65f);
    glVertex2f(personX + 0.04f, -0.45f);
    glVertex2f(personX - 0.04f, -0.45f);
    glEnd();

    /* Legs */
    glColor3f(0.10f, 0.10f, 0.10f);

    glBegin(GL_LINES);

    glVertex2f(personX, -0.65f);
    glVertex2f(personX - 0.06f, -0.80f);

    glVertex2f(personX, -0.65f);
    glVertex2f(personX + 0.06f, -0.80f);

    /* Arms */
    glVertex2f(personX - 0.04f, -0.50f);
    glVertex2f(personX - 0.10f, -0.58f);

    glVertex2f(personX + 0.04f, -0.50f);
    glVertex2f(personX + 0.10f, -0.58f);

    glEnd();
}

/* ---------------- GROUND ---------------- */

void drawGround()
{
    glColor3f(0.20f, 0.65f, 0.20f);

    glBegin(GL_QUADS);
    glVertex2f(-1.0f, -1.0f);
    glVertex2f(1.0f, -1.0f);
    glVertex2f(1.0f, -0.55f);
    glVertex2f(-1.0f, -0.55f);
    glEnd();

    /* Path */
    glColor3f(0.65f, 0.50f, 0.35f);

    glBegin(GL_QUADS);
    glVertex2f(-0.15f, -1.0f);
    glVertex2f(0.20f, -1.0f);
    glVertex2f(0.10f, -0.55f);
    glVertex2f(-0.05f, -0.55f);
    glEnd();
}

/* ---------------- DISPLAY ---------------- */

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);

    /* Sky */
    glClearColor(skyR, skyG, skyB, 1.0f);

    /* Background */
    if (!night)
    {
        drawSun();

        drawCloud(cloudX, 0.55f);
        drawCloud(cloudX + 0.60f, 0.75f);
    }
    else
    {
        drawStars();
        drawMoon();
    }

    drawGround();

    drawTree(-0.80f, -0.55f);
    drawTree(0.75f, -0.55f);

    drawHouse();

    drawPerson();

    glutSwapBuffers();
}

/* ---------------- ANIMATION ---------------- */

void update(int value)
{
    if (animation)
    {
        /* Sun movement */
        sunX += 0.004f;

        if (sunX > 1.2f)
        {
            sunX = -1.2f;
            night = !night;
        }

        /* Cloud movement */
        cloudX += 0.0025f;

        if (cloudX > 1.3f)
            cloudX = -1.3f;

        /* Person walking */
        personX += 0.002f;

        if (personX > -0.20f)
            doorOpen = 1;

        if (personX > 0.15f)
            personX = -1.2f;

        /* Fan rotation */
        fanAngle += 5.0f;

        if (fanAngle > 360.0f)
            fanAngle -= 360.0f;
    }

    glutPostRedisplay();
    glutTimerFunc(16, update, 0);
}

/* ---------------- KEYBOARD ---------------- */

void keyboard(unsigned char key, int x, int y)
{
    switch (key)
    {
        case 's':
        case 'S':
            animation = 1;
            break;

        case 'p':
        case 'P':
            animation = 0;
            break;

        case 'd':
        case 'D':
            night = 0;
            sunX = -0.8f;
            break;

        case 'n':
        case 'N':
            night = 1;
            break;

        case 'o':
        case 'O':
            doorOpen = !doorOpen;
            break;

        case 'r':
        case 'R':
            sunX = -0.8f;
            cloudX = -1.2f;
            personX = -1.2f;
            night = 0;
            doorOpen = 0;
            fanAngle = 0;
            animation = 1;
            break;

        case 27:
            exit(0);
            break;
    }

    glutPostRedisplay();
}

/* ---------------- INITIALIZATION ---------------- */

void init()
{
    glClearColor(0.35f, 0.70f, 0.95f, 1.0f);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    gluOrtho2D(-1.0, 1.0, -1.0, 1.0);

    glMatrixMode(GL_MODELVIEW);
}

/* ---------------- MAIN ---------------- */

int main(int argc, char **argv)
{
    glutInit(&argc, argv);

    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);

    glutInitWindowSize(900, 650);

    glutInitWindowPosition(100, 50);

    glutCreateWindow("Animated Home Scene - Computer Graphics");

    init();

    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);

    glutTimerFunc(0, update, 0);

    glutMainLoop();

    return 0;
}
